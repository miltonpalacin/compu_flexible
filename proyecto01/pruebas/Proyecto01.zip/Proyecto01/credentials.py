xmpp_user_1 = 'rarias@chatterboxtown.us'
xmpp_pass_1 = "rarias"

xmpp_user_2 = 'mpalacin@chatterboxtown.us'
xmpp_pass_2 = "mpalacin"